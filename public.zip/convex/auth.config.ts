export default {
    providers: [
      {
        domain: "https://daring-weasel-31.clerk.accounts.dev/",
        applicationID: "convex",
      },
    ]
  };