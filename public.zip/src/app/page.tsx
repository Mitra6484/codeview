import LandingPage from "@/components/LandingPage";

export default function RootPage() {
  return <LandingPage />;
}
